# Sweep 6 handoff — Swift-side tokenization via `swift-transformers`

You are picking this up cold. Read this whole file once, then start.

## Where the project is

This is a macOS TTS app. The original was a FastAPI Python server hidden behind
a WKWebView shell. Over five sweeps we've reshaped it into:

- **Swift app shell + Hummingbird HTTP server** — `swift/MossTTSApp.swift` (one
  file, ~1000 LOC). `@MainActor AppDelegate` + `actor InferenceManager`. Swift
  6.3 strict concurrency, default-MainActor isolation; cross-actor types are
  explicitly `nonisolated`.
- **Python ML subprocess** — `backend/inference.py` (~390 LOC). No HTTP, no
  FastAPI, no multipart, no soundfile, no librosa. Reads newline-delimited
  JSON on stdin; emits status frames and synthesis results on stdout.
- **Build pipeline is Python-free.** Icon + DMG-background generation moved
  from Pillow to native CoreGraphics scripts (`scripts/make_icon.swift`,
  `scripts/make_dmg_bg.swift`). Login items use `SMAppService` (macOS 13+).

Five sweeps in commit history; key shape:
- Sweep 1 — Swift 6.3 strict concurrency, actor IPC, native WAV encoder.
- Sweep 2 — Deleted `server.py`. Added `inference.py` (stdin/stdout JSON).
  Added Swift endpoints (`/api/models`, voice upload/delete, load/unload).
- Sweep 3 — `SMAppService` for login items. Multipart parser → raw bytes.
- Sweep 4 — Pillow → CoreGraphics for icon/DMG.
- Sweep 5 — WAV encoding moved Python → Swift. `soundfile` + `librosa`
  removed from `requirements.txt` after static probe confirmed MOSS-TTS uses
  only `torchaudio`.

## Current IPC contract (what you'll be changing)

Python → Swift, one JSON line per frame:

```
{"status": "starting"}
{"status": "loading", "progress": 30, "message": "Loading tokenizer..."}
{"status": "ready",   "model_id": "...", "device": "mps", "models_dir": "..."}
{"status": "generating", "message": "Generating audio..."}
{"status": "idle"}
{"status": "error", "error": "..."}
{"pcm_path": "/.../pcm-tmp/moss_xxxx.f32",
 "sample_rate": 22050, "samples": 70560, "duration": 3.2}
{"error": "synthesis failed: ..."}
```

PCM hand-off file is raw little-endian mono float32. Swift reads it,
WAV-encodes via `pcmFloat32ToWAV(pcm:sampleRate:)`, saves to
`~/Desktop/MOSSlanding/mosslanding_<8hex>.wav`, unlinks the temp.

Swift → Python, one JSON line per command:

```
{"op": "synthesize", "text": "...", "voice": "alice.wav", "mode": "clone",
 "quality": 32, "temperature": 1.7, "top_p": 0.8, ...}
{"op": "load"} | {"op": "unload"} | {"op": "status"} | {"op": "shutdown"}
```

Currently `text` is plain text. **That's the field you're going to replace.**

## The goal of sweep 6

Move text tokenization out of Python. Send pre-tokenized `input_ids` +
`attention_mask` over the IPC instead of raw text. After this sweep, `tiktoken`
drops from `requirements.txt`, and we have a real bridgehead for moving the
LM forward pass to MLX-Swift in sweep 7.

This is the first sweep that adds Rust to the project — `swift-transformers`
embeds the HuggingFace `tokenizers-rs` crate.

## What MOSS-TTS's processor actually does

Authoritative source is the trust_remote_code in the model cache:

```
~/Library/Application Support/MOSSlanding/models/hub/
  models--OpenMOSS-Team--MOSS-TTS-Local-Transformer/
    snapshots/12aa734e4f11a7b3fdf4eb0ad2aa2029675ffc2e/
      processing_moss_tts.py       ← the processor logic
      modeling_moss_tts.py
      inference_utils.py
      configuration_moss_tts.py
```

Two calls happen today in `inference.py::_synthesize`:

```python
conversation = [processor.build_user_message(text=text, **msg_kwargs)]
batch = processor([conversation], mode="generation")
input_ids = batch["input_ids"].to(device)
attention_mask = batch["attention_mask"].to(device)
```

`build_user_message()` builds a chat-style message dict. The `msg_kwargs` we
pass include `language`, `reference` (list of voice WAV paths), and `tokens`
(duration control). The processor's `__call__` then turns that conversation
into `input_ids` + `attention_mask` tensors via the chat template + tokenizer.

**Read `processing_moss_tts.py` first.** Specifically you need to understand:
- How `build_user_message` lays out tokens (special tokens, role markers,
  audio-reference placeholders).
- Whether the chat-template path uses a Jinja template stored in
  `tokenizer_config.json` (HF standard) — if yes, swift-transformers can
  render it. If MOSS-TTS does template assembly in Python, you'll need to
  port that logic too.
- The reference-voice path: `processor.audio_tokenizer.encode(wav)` is what
  actually generates the audio tokens that get embedded inline. **That's the
  audio tokenizer (MOSS-Audio-Tokenizer model).** It's a separate sub-module
  cached at `models--OpenMOSS-Team--MOSS-Audio-Tokenizer`. Converting it to
  CoreML is sweep 7's job — leave clone mode Python-resident this sweep.

## Recommended sequence

### Step A — Read MOSS-TTS source (no edits)

```bash
less '~/Library/Application Support/MOSSlanding/models/hub/models--OpenMOSS-Team--MOSS-TTS-Local-Transformer/snapshots/12aa734e4f11a7b3fdf4eb0ad2aa2029675ffc2e/processing_moss_tts.py'
```

Find `build_user_message` and `__call__`. Note which special-token IDs and
chat-template scaffolding they emit. Look for `chat_template` references —
if it's loaded from `tokenizer_config.json`, you're in luck; swift-
transformers' `Tokenizer` exposes `applyChatTemplate(messages:)`.

### Step B — Add `swift-transformers` to the project

In Xcode: File → Add Package Dependencies → enter
`https://github.com/huggingface/swift-transformers`. Pick the latest stable
version. Add the `Transformers` product to the `Mosslanding-Sync` target.

Note the existing SwiftPM deps for context (hummingbird, swift-nio, etc. —
all NIO/HTTP stack). Adding `swift-transformers` is the only new package this
sweep.

### Step C — Wire the tokenizer

`swift-transformers` API (current as of 2026):

```swift
import Tokenizers
import Hub

let modelDir = AppPaths.modelsHubDirectory
  .appending(path: "models--OpenMOSS-Team--MOSS-TTS-Local-Transformer/snapshots/<rev>")
let tokenizer = try await AutoTokenizer.from(modelFolder: modelDir)
let ids = tokenizer.encode(text: "hello")
let chatTemplated = try tokenizer.applyChatTemplate(messages: messages)
```

Concerns:
- The `<rev>` hash isn't stable across model updates. Resolve it by reading
  `refs/main` in the cache dir or by globbing `snapshots/*`.
- `AutoTokenizer.from(modelFolder:)` is async and may block on first call.
  Wrap in a `Task` and cache the result inside `InferenceManager`.

Add a `nonisolated` actor or struct that owns the loaded tokenizer. Don't
put it inside `@MainActor AppDelegate` — it should live with the
`InferenceManager` actor or be a peer actor.

### Step D — Extend the IPC

Update `Mosslanding-Sync/swift/MossTTSApp.swift::SynthRequest.toPayload()` to
send `input_ids` + `attention_mask` (arrays of Int) when the request is in
text-only mode (`mode == "direct"` or `voice == nil`). Keep sending `text` +
`reference` for clone mode (sweep 7 will fix that).

Update `Mosslanding-Sync/backend/inference.py::_synthesize` to accept
either shape. Detect `input_ids` presence and skip the
`processor.build_user_message` / `processor([conv], ...)` path; build the
tensors directly:

```python
if "input_ids" in req:
    input_ids = torch.tensor([req["input_ids"]], dtype=torch.long, device=device)
    attention_mask = torch.tensor(
        [req["attention_mask"]], dtype=torch.long, device=device
    ) if "attention_mask" in req else torch.ones_like(input_ids)
else:
    # existing path
```

### Step E — Trim `tiktoken`

After confirming direct-mode synthesis works end-to-end, drop `tiktoken` from
`backend/requirements.txt` and `setup.sh`.

### Step F — Document and stop

Leave clone mode hitting the Python tokenizer path. Note in this file (or a
new `HANDOFF.md`) what's left for sweep 7: audio tokenizer to CoreML + clone
mode in Swift.

## Files you will touch

| File | What changes |
|------|--------------|
| `Mosslanding-Sync/swift/MossTTSApp.swift` | New tokenizer integration; `SynthRequest.toPayload()` branch; possibly a new `Tokenization` enum/actor. |
| `Mosslanding-Sync/backend/inference.py` | `_synthesize()` accepts `input_ids` shape. |
| `Mosslanding-Sync/backend/requirements.txt` | `tiktoken` removed after verification. |
| `Mosslanding-Sync/setup.sh` | `tiktoken` removed from `pip install`. |
| `Mosslanding-Sync.xcodeproj/project.pbxproj` | New SwiftPM dep registered (via Xcode UI). |

## Files you should NOT touch

- `scripts/make_icon.swift`, `scripts/make_dmg_bg.swift` — build-time only, working.
- `build.sh`, `dist.sh` — working.
- `webui/index.html` — sweep 8 will replace it with SwiftUI; until then the
  UI contract is stable. The synthesize/voices/models endpoints should keep
  returning the same shape.
- `Mosslanding-Sync/Mosslanding-Sync/Mosslanding_SyncApp.swift`, `ContentView.swift`,
  `Item.swift` — placeholder SwiftUI shell, orphaned. Leave for sweep 8.
- `MOSSlanding.app/` bundle — build artifact, rebuilt by `BuildProject` / `build.sh`.

## Constraints to respect

- **Swift 6.3 strict concurrency, default-MainActor mode.** Top-level
  declarations are inferred MainActor-isolated unless marked `nonisolated`.
  When in doubt, see what surrounding types do.
- **No new dependencies beyond `swift-transformers`.** If you want HF Hub
  download support too (e.g. to fetch tokenizer.json automatically), the
  `Hub` module of swift-transformers covers it — don't add a separate HTTP
  client.
- **Don't break clone mode.** Until the audio tokenizer is in Swift, voice
  cloning HAS to keep flowing through Python. Branch on `mode` or on
  `input_ids` presence.
- **Don't bypass `InferenceManager`.** All Python IPC must go through the
  actor. The tokenizer is also state — model load + tokenizer load should be
  coordinated.

## Pitfalls to expect

1. **The `<rev>` snapshot hash is non-obvious.** Use the HF cache convention:
   `models--<org>--<model>/refs/main` contains the resolved commit hash; the
   snapshot is at `snapshots/<that-hash>/`. There's a `huggingface_hub`
   utility for this in Python but you don't want to call out to it from
   Swift — read the file directly.
2. **swift-transformers may not expose every HF tokenizer feature you need.**
   If `applyChatTemplate` doesn't handle MOSS-TTS's audio-reference
   placeholders, fall back to manual token assembly in Swift. The processor
   code is the spec.
3. **`Mutex` and `Synchronization`** — Swift 6.2+ has a real `Mutex` type in
   the `Synchronization` module. For caching the loaded tokenizer across
   `InferenceManager` calls, prefer storing it as an actor field instead of
   reaching for `Mutex` — the actor isolation already gives you what you
   need.
4. **First-load latency.** Loading the tokenizer on the first synthesis call
   adds ~200ms. Trigger it eagerly in `InferenceManager.start()` alongside
   the Python subprocess spawn.

## Verification

After your edits:

1. Build the project (Xcode MCP `BuildProject` tool, or `xcodebuild` from CLI).
2. Smoke test direct-mode synthesis:
   ```bash
   curl -fsS http://127.0.0.1:8765/api/load -X POST
   # wait for /api/status to report "ready"
   curl -fsS http://127.0.0.1:8765/api/status
   curl -fsS http://127.0.0.1:8765/api/synthesize \
     -H 'Content-Type: application/json' \
     -d '{"text": "Hello from Swift tokenization.", "mode": "direct", "quality": 16}' \
     -o /tmp/test.wav
   afplay /tmp/test.wav
   ```
3. Confirm clone mode still works:
   ```bash
   # upload a reference voice via the webui first, then:
   curl -fsS http://127.0.0.1:8765/api/synthesize \
     -H 'Content-Type: application/json' \
     -d '{"text": "Clone path still alive.", "voice": "alice.wav", "mode": "clone"}' \
     -o /tmp/clone.wav
   ```
4. Confirm Python no longer imports `tiktoken`:
   ```bash
   grep -r tiktoken backend/
   # should return no matches in our code; transformers' internal usage is fine.
   ```

## Don't forget

- After you commit, append a "sweep 6" section to git history with a one-line
  summary of what moved.
- The bundled `MOSSlanding.app/Contents/Resources/backend/server.py` listed
  in the project file tree is a STALE artifact from before sweep 2 — it
  predates the FastAPI deletion. Either rebuild the bundle via `build.sh`
  (which copies the current `backend/` over) or leave it; it doesn't affect
  the Xcode-built target.

Good luck. Keep it tight.
