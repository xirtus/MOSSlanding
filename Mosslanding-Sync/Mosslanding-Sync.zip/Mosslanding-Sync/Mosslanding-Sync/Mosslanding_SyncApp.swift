import SwiftUI

@main
struct Mosslanding_SyncApp: App {

    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        // The user-facing UI is a WKWebView-hosted window managed by
        // AppDelegate as a menu-bar (accessory) app. We expose a Settings
        // scene as a placeholder so SwiftUI has a Scene to vend; no default
        // WindowGroup is needed and would fight the accessory activation
        // policy.
        Settings { EmptyView() }
    }
}
