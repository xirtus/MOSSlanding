import AppKit
import AVFoundation
import Foundation
import HTTPTypes
import Hummingbird
import NIOCore
import OSLog
import ServiceManagement
import UniformTypeIdentifiers
import WebKit

// MARK: - Logging

nonisolated let logger = Logger(subsystem: "com.mosslanding.app", category: "main")

// MARK: - Errors

nonisolated enum InferenceError: Error, Sendable {
    case notRunning
    case scriptNotFound
    case backendError(String)
    case ioFailure(String)
}

// MARK: - Inference IPC types

/// One line from the Python subprocess's stdout. Decoded loosely because each
/// line may be either a status update, a synthesis result, or a synthesis
/// error — distinguished by which fields are present.
private nonisolated struct InferenceLine: Decodable {
    let status: String?
    let progress: Int?
    let message: String?
    let modelId: String?
    let device: String?
    let modelsDir: String?
    let error: String?
    let pcmPath: String?
    let sampleRate: Int?
    let samples: Int?
    let duration: Double?

    enum CodingKeys: String, CodingKey {
        case status, progress, message, device, error, samples, duration
        case modelId    = "model_id"
        case modelsDir  = "models_dir"
        case pcmPath    = "pcm_path"
        case sampleRate = "sample_rate"
    }
}

// MARK: - Public status and synth result types

nonisolated struct InferenceStatus: ResponseCodable, Sendable {
    var status: String
    var progress: Int
    var message: String
    var modelId: String
    var device: String
    var modelsDir: String
    var error: String

    enum CodingKeys: String, CodingKey {
        case status, progress, message, device, error
        case modelId   = "model_id"
        case modelsDir = "models_dir"
    }

    static let initial = InferenceStatus(
        status: "starting",
        progress: 0,
        message: "",
        modelId: "moss-local-1.7b",
        device: "unknown",
        modelsDir: "",
        error: ""
    )
}

nonisolated struct SynthResult: Sendable {
    let wavData: Data
    let filename: String
    let savedPath: String
    let sampleRate: Int
    let duration: Double
}

// MARK: - WAV encoding (mono float32 PCM → 16-bit signed PCM WAV)

/// Encodes raw little-endian float32 mono PCM as a 16-bit signed PCM WAV
/// in memory. No temp file, no AVAudioFile round-trip.
nonisolated func pcmFloat32ToWAV(pcm: Data, sampleRate: Int) -> Data {
    let sampleCount = pcm.count / MemoryLayout<Float>.size
    var int16 = [Int16](repeating: 0, count: sampleCount)
    pcm.withUnsafeBytes { raw in
        guard let floats = raw.baseAddress?.assumingMemoryBound(to: Float.self) else { return }
        for i in 0..<sampleCount {
            let s = max(-1.0, min(1.0, floats[i]))
            int16[i] = Int16(s * 32767.0)
        }
    }
    let dataSize = int16.count * MemoryLayout<Int16>.size
    let byteRate = sampleRate * 2

    var wav = Data(capacity: 44 + dataSize)
    wav.append(contentsOf: "RIFF".utf8)
    wav.appendLittleEndian(UInt32(36 + dataSize))
    wav.append(contentsOf: "WAVE".utf8)
    wav.append(contentsOf: "fmt ".utf8)
    wav.appendLittleEndian(UInt32(16))         // fmt chunk size
    wav.appendLittleEndian(UInt16(1))          // PCM
    wav.appendLittleEndian(UInt16(1))          // channels
    wav.appendLittleEndian(UInt32(sampleRate))
    wav.appendLittleEndian(UInt32(byteRate))
    wav.appendLittleEndian(UInt16(2))          // block align
    wav.appendLittleEndian(UInt16(16))         // bits per sample
    wav.append(contentsOf: "data".utf8)
    wav.appendLittleEndian(UInt32(dataSize))
    int16.withUnsafeBytes { wav.append(contentsOf: $0) }
    return wav
}

private nonisolated extension Data {
    mutating func appendLittleEndian<T: FixedWidthInteger>(_ value: T) {
        var le = value.littleEndian
        Swift.withUnsafeBytes(of: &le) { append(contentsOf: $0) }
    }
}

// MARK: - Inference Manager

/// Owns the Python inference subprocess and serializes requests through a
/// newline-delimited JSON protocol. All mutable state is actor-isolated;
/// arbitrary-queue `FileHandle` callbacks bridge back in via `Task { await ... }`.
actor InferenceManager {
    static let shared = InferenceManager()

    private var process: Process?
    private var stdin: FileHandle?
    private var readBuffer = ""
    private var pending: [CheckedContinuation<SynthResult, Error>] = []
    private(set) var status: InferenceStatus = .initial

    private init() {}

    func currentStatus() -> InferenceStatus { status }

    func start() {
        guard process == nil else { return }
        guard let (python, script) = findPythonAndScript() else {
            logger.error("Cannot find python or inference.py")
            status.status = "error"
            status.error = "Python or inference.py not found"
            return
        }

        let proc = Process()
        proc.executableURL = URL(fileURLWithPath: python)
        proc.arguments = [script]
        var env = ProcessInfo.processInfo.environment
        env["MOSS_TTS_MODEL_ID"] = "OpenMOSS-Team/MOSS-TTS-Local-Transformer"
        // Apple Silicon: cap MPS allocator so it can't pin all unified memory,
        // and bound OpenMP threads so PyTorch doesn't oversubscribe P/E cores.
        // Previously set via the launchd plist; pinning them here means they
        // apply whether the app is launched at login, from /Applications, or
        // from Xcode.
        env["PYTORCH_MPS_HIGH_WATERMARK_RATIO"] = "0.0"
        env["OMP_NUM_THREADS"] = "4"
        proc.environment = env

        let stdinPipe = Pipe()
        let stdoutPipe = Pipe()
        let stderrPipe = Pipe()
        proc.standardInput = stdinPipe
        proc.standardOutput = stdoutPipe
        proc.standardError = stderrPipe

        stderrPipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty, let s = String(data: data, encoding: .utf8) else { return }
            let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
            logger.debug("inference: \(trimmed, privacy: .public)")
        }
        stdoutPipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty else { return }
            Task { await InferenceManager.shared.ingest(data) }
        }

        do {
            try proc.run()
            process = proc
            stdin = stdinPipe.fileHandleForWriting
            status.status = "starting"
            status.progress = 0
            status.message = "Starting Python..."
            status.error = ""
            logger.info("Inference started (pid \(proc.processIdentifier, privacy: .public))")
        } catch {
            logger.error("Inference start failed: \(error.localizedDescription, privacy: .public)")
            status.status = "error"
            status.error = error.localizedDescription
        }
    }

    func terminate() {
        let outstanding = pending
        pending.removeAll()
        for cont in outstanding {
            cont.resume(throwing: InferenceError.notRunning)
        }
        if let stdin {
            try? sendCommand(["op": "shutdown"], using: stdin)
        }
        process?.terminate()
        process = nil
        stdin = nil
        readBuffer = ""
        status = .initial
    }

    /// Restarts the subprocess if it died (e.g. broken stdin pipe after wake).
    func restartIfNeeded() {
        if let process, process.isRunning { return }
        terminate()
        start()
    }

    func triggerLoad() {
        guard let stdin else { return }
        try? sendCommand(["op": "load"], using: stdin)
    }

    func triggerUnload() {
        guard let stdin else { return }
        try? sendCommand(["op": "unload"], using: stdin)
    }

    func synthesize(_ params: [String: any Sendable]) async throws -> SynthResult {
        guard let stdin, process?.isRunning == true else {
            throw InferenceError.notRunning
        }
        var payload = params
        payload["op"] = "synthesize"

        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<SynthResult, Error>) in
            pending.append(cont)
            do {
                try sendCommand(payload, using: stdin)
            } catch {
                _ = pending.popLast()
                cont.resume(throwing: error)
            }
        }
    }

    private func sendCommand(_ payload: [String: any Sendable], using handle: FileHandle) throws {
        var data = try JSONSerialization.data(withJSONObject: payload, options: [])
        data.append(0x0A)
        try handle.write(contentsOf: data)
    }

    fileprivate func ingest(_ data: Data) {
        guard let chunk = String(data: data, encoding: .utf8) else { return }
        readBuffer.append(chunk)
        while let newline = readBuffer.firstIndex(of: "\n") {
            let line = String(readBuffer[..<newline])
            readBuffer.removeSubrange(...newline)
            guard let lineData = line.data(using: .utf8), !lineData.isEmpty else { continue }
            handleLine(lineData)
        }
    }

    private func handleLine(_ data: Data) {
        let line: InferenceLine
        do {
            line = try JSONDecoder().decode(InferenceLine.self, from: data)
        } catch {
            logger.warning("Bad inference line: \(error.localizedDescription, privacy: .public)")
            return
        }

        // Status update path: has `status` field.
        if let s = line.status {
            status.status = s
            if let p = line.progress { status.progress = p }
            if let m = line.message  { status.message = m }
            if let id = line.modelId { status.modelId = id }
            if let dev = line.device { status.device = dev }
            if let md = line.modelsDir { status.modelsDir = md }
            status.error = line.error ?? ""
            return
        }

        // Synthesis success path: has `pcm_path`. Python wrote raw float32
        // little-endian samples; we encode WAV ourselves, save on Desktop,
        // and unlink the temp.
        if let path = line.pcmPath, let sr = line.sampleRate {
            guard !pending.isEmpty else { return }
            let cont = pending.removeFirst()
            do {
                let pcm = try Data(contentsOf: URL(fileURLWithPath: path))
                try? FileManager.default.removeItem(atPath: path)
                let wav = pcmFloat32ToWAV(pcm: pcm, sampleRate: sr)

                let outDir = AppPaths.outputDirectory
                try? FileManager.default.createDirectory(at: outDir, withIntermediateDirectories: true)
                let filename = "mosslanding_\(UUID().uuidString.prefix(8).lowercased()).wav"
                let savedURL = outDir.appendingPathComponent(filename)
                try? wav.write(to: savedURL)

                let result = SynthResult(
                    wavData: wav,
                    filename: filename,
                    savedPath: savedURL.path,
                    sampleRate: sr,
                    duration: line.duration
                        ?? (line.samples.map { Double($0) / Double(sr) } ?? 0)
                )
                cont.resume(returning: result)
            } catch {
                cont.resume(throwing: InferenceError.ioFailure("read pcm: \(error.localizedDescription)"))
            }
            return
        }

        // Synthesis error path: only `error`.
        if let message = line.error {
            guard !pending.isEmpty else { return }
            let cont = pending.removeFirst()
            cont.resume(throwing: InferenceError.backendError(message))
        }
    }

    nonisolated private func findPythonAndScript() -> (String, String)? {
        let python = "/opt/homebrew/bin/python3"
        guard FileManager.default.fileExists(atPath: python),
              let script = Bundle.main.url(
                forResource: "inference",
                withExtension: "py",
                subdirectory: "backend"
              )
        else { return nil }
        return (python, script.path)
    }
}

// MARK: - Synthesis request (mirrors the webui's full param set)

nonisolated struct SynthRequest: Decodable, Sendable {
    let text: String
    let language: String?
    let voice: String?
    let mode: String?
    let maxNewTokens: Int?
    let durationTokens: Int?
    let quality: Int?
    let temperature: Double?
    let topP: Double?
    let topK: Int?
    let repetitionPenalty: Double?
    let doSample: Bool?

    enum CodingKeys: String, CodingKey {
        case text, language, voice, mode, quality, temperature
        case maxNewTokens      = "max_new_tokens"
        case durationTokens    = "duration_tokens"
        case topP              = "top_p"
        case topK              = "top_k"
        case repetitionPenalty = "repetition_penalty"
        case doSample          = "do_sample"
    }

    func toPayload() -> [String: any Sendable] {
        var out: [String: any Sendable] = ["text": text]
        if let language          { out["language"] = language }
        if let voice             { out["voice"] = voice }
        if let mode              { out["mode"] = mode }
        if let maxNewTokens      { out["max_new_tokens"] = maxNewTokens }
        if let durationTokens    { out["duration_tokens"] = durationTokens }
        if let quality           { out["quality"] = quality }
        if let temperature       { out["temperature"] = temperature }
        if let topP              { out["top_p"] = topP }
        if let topK              { out["top_k"] = topK }
        if let repetitionPenalty { out["repetition_penalty"] = repetitionPenalty }
        if let doSample          { out["do_sample"] = doSample }
        return out
    }
}

// MARK: - Voice + model catalogue types

nonisolated struct VoiceInfo: Codable, Sendable {
    let name: String
    let filename: String
    let size: Int
}

nonisolated struct VoicesResponse: ResponseCodable, Sendable {
    let voices: [VoiceInfo]
}

nonisolated struct ModelInfo: ResponseCodable, Sendable {
    let key: String
    let id: String
    let description: String
    let sizeGb: Double
    let recommended: Bool
    let downloaded: Bool
    let active: Bool

    enum CodingKeys: String, CodingKey {
        case key, id, description, recommended, downloaded, active
        case sizeGb = "size_gb"
    }
}

nonisolated struct ModelsResponse: ResponseCodable, Sendable {
    let models: [ModelInfo]
    let modelsDir: String

    enum CodingKeys: String, CodingKey {
        case models
        case modelsDir = "models_dir"
    }
}

// MARK: - Model catalogue

nonisolated enum ModelCatalogue {
    struct Entry: Sendable {
        let key: String
        let id: String
        let description: String
        let sizeGb: Double
        let recommended: Bool
    }

    static let entries: [Entry] = [
        Entry(
            key: "moss-local-1.7b",
            id: "OpenMOSS-Team/MOSS-TTS-Local-Transformer",
            description: "MOSS TTS Local Transformer 1.7B — fast, M-series optimised",
            sizeGb: 3.5,
            recommended: true
        ),
        Entry(
            key: "moss-v1.5-8b",
            id: "OpenMOSS-Team/MOSS-TTS-v1.5",
            description: "MOSS TTS v1.5 8B — highest quality, needs 16 GB+ RAM",
            sizeGb: 16.0,
            recommended: false
        ),
    ]

    static let activeModelId = "OpenMOSS-Team/MOSS-TTS-Local-Transformer"

    static func snapshot() -> ModelsResponse {
        let hubDir = AppPaths.modelsHubDirectory
        let models = entries.map { entry -> ModelInfo in
            let slug = "models--" + entry.id.replacingOccurrences(of: "/", with: "--")
            let downloaded = FileManager.default.fileExists(
                atPath: hubDir.appendingPathComponent(slug).path
            )
            return ModelInfo(
                key: entry.key,
                id: entry.id,
                description: entry.description,
                sizeGb: entry.sizeGb,
                recommended: entry.recommended,
                downloaded: downloaded,
                active: entry.id == activeModelId
            )
        }
        return ModelsResponse(models: models, modelsDir: AppPaths.modelsDirectory.path)
    }
}

// MARK: - HTTP server

nonisolated func buildServer(webuiDir: URL) -> Application<RouterResponder<BasicRequestContext>> {
    let router = Router(context: BasicRequestContext.self)

    router.add(middleware: CORSMiddleware(
        allowOrigin: .all,
        allowHeaders: [.accept, .authorization, .contentType, .origin],
        allowMethods: [.get, .post, .options, .delete, .put, .head]
    ))

    // ── Status ────────────────────────────────────────────────────────────
    router.get("/api/status") { _, _ -> InferenceStatus in
        await InferenceManager.shared.currentStatus()
    }

    // ── Models catalogue ──────────────────────────────────────────────────
    router.get("/api/models") { _, _ -> ModelsResponse in
        ModelCatalogue.snapshot()
    }

    // ── Trigger load / unload ─────────────────────────────────────────────
    router.post("/api/load") { _, _ -> Response in
        await InferenceManager.shared.triggerLoad()
        return Self_jsonOK()
    }
    router.post("/api/unload") { _, _ -> Response in
        await InferenceManager.shared.triggerUnload()
        return Self_jsonOK()
    }

    // ── Synthesize ────────────────────────────────────────────────────────
    router.post("/api/synthesize") { request, context -> Response in
        let body = try await request.decode(as: SynthRequest.self, context: context)
        do {
            let result = try await InferenceManager.shared.synthesize(body.toPayload())
            var resp = Response(status: .ok)
            resp.headers[.contentType] = "audio/wav"
            resp.headers[HTTPField.Name("X-Saved-Path")!] = result.savedPath
            resp.headers[HTTPField.Name("X-Filename")!]   = result.filename
            var buf = ByteBuffer()
            buf.writeBytes(result.wavData)
            resp.body = .init(byteBuffer: buf)
            return resp
        } catch InferenceError.backendError(let message) {
            logger.warning("Synthesize backend error: \(message, privacy: .public)")
            throw HTTPError(.internalServerError, message: message)
        } catch {
            logger.error("Synthesize failed: \(error.localizedDescription, privacy: .public)")
            throw HTTPError(.internalServerError)
        }
    }

    // ── List voices ───────────────────────────────────────────────────────
    router.get("/api/voices") { _, _ -> VoicesResponse in
        let voicesDir = AppPaths.voicesDirectory
        let allowed: Set<String> = ["wav", "mp3", "m4a", "flac", "ogg"]
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: voicesDir,
            includingPropertiesForKeys: [.fileSizeKey]
        )) ?? []
        let voices = urls
            .filter { allowed.contains($0.pathExtension.lowercased()) }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
            .compactMap { url -> VoiceInfo? in
                guard let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize else { return nil }
                return VoiceInfo(
                    name: url.deletingPathExtension().lastPathComponent,
                    filename: url.lastPathComponent,
                    size: size
                )
            }
        return VoicesResponse(voices: voices)
    }

    // ── Upload voice (raw bytes + headers) ────────────────────────────────
    // Contract: POST /api/voices/upload with the audio bytes as the body,
    // X-Filename: <original.ext> and (optional) X-Voice-Name: <stem>.
    router.post("/api/voices/upload") { request, _ -> Response in
        guard let xFilename = HTTPField.Name("X-Filename"),
              let originalName = request.headers[xFilename] else {
            throw HTTPError(.badRequest, message: "missing X-Filename header")
        }
        let suppliedName = HTTPField.Name("X-Voice-Name").flatMap { request.headers[$0] }

        let ext = (originalName as NSString).pathExtension.lowercased()
        let allowed: Set<String> = ["wav", "mp3", "m4a", "flac", "ogg"]
        guard allowed.contains(ext) else {
            throw HTTPError(.badRequest, message: "unsupported audio format: \(ext)")
        }
        let rawStem = suppliedName ?? (originalName as NSString).deletingPathExtension
        let stem = sanitizeVoiceStem(rawStem)

        var buffer = try await request.body.collect(upTo: 200 * 1024 * 1024)
        let bytes = buffer.readBytes(length: buffer.readableBytes) ?? []
        let data = Data(bytes)

        let voicesDir = AppPaths.voicesDirectory
        try? FileManager.default.createDirectory(at: voicesDir, withIntermediateDirectories: true)
        let dest = voicesDir.appendingPathComponent("\(stem).\(ext)")
        do {
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try data.write(to: dest)
        } catch {
            throw HTTPError(.internalServerError, message: "write failed: \(error.localizedDescription)")
        }
        return Self_jsonResponse([
            "ok": true,
            "filename": dest.lastPathComponent,
            "name": stem,
        ])
    }

    // ── Delete voice ──────────────────────────────────────────────────────
    router.delete("/api/voices/:filename") { _, context -> Response in
        let filename = try context.parameters.require("filename", as: String.self)
        // Defence in depth: reject path traversal.
        guard !filename.contains("/"), !filename.contains(".."), !filename.isEmpty else {
            throw HTTPError(.badRequest, message: "invalid filename")
        }
        let target = AppPaths.voicesDirectory.appendingPathComponent(filename)
        guard FileManager.default.fileExists(atPath: target.path) else {
            throw HTTPError(.notFound, message: "voice not found")
        }
        try FileManager.default.removeItem(at: target)
        return Self_jsonOK()
    }

    // ── Serve web UI (catch-all) ──────────────────────────────────────────
    router.group()
        .add(middleware: FileMiddleware(webuiDir.path, searchForIndexHtml: true))
        .get("**") { _, _ -> Response in
            throw HTTPError(.notFound)
        }

    return Application(
        router: router,
        configuration: .init(address: .hostname("127.0.0.1", port: 8765))
    )
}

// MARK: - Response helpers

nonisolated private func Self_jsonOK() -> Response {
    Self_jsonResponse(["ok": true])
}

nonisolated private func Self_jsonResponse(_ object: [String: Any]) -> Response {
    let data = (try? JSONSerialization.data(withJSONObject: object, options: [])) ?? Data("{}".utf8)
    var resp = Response(status: .ok)
    resp.headers[.contentType] = "application/json"
    var buf = ByteBuffer()
    buf.writeBytes(data)
    resp.body = .init(byteBuffer: buf)
    return resp
}

nonisolated private func sanitizeVoiceStem(_ raw: String) -> String {
    let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "_- "))
    let filtered = raw.unicodeScalars.filter { allowed.contains($0) }
    let cleaned = String(String.UnicodeScalarView(filtered))
        .trimmingCharacters(in: .whitespaces)
    let truncated = String(cleaned.prefix(40))
    if truncated.isEmpty {
        return "voice_" + UUID().uuidString.prefix(6).lowercased()
    }
    return truncated
}

// MARK: - App paths

nonisolated enum AppPaths {
    static var supportDirectory: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appending(path: "Library/Application Support/MOSSlanding", directoryHint: .isDirectory)
    }
    static var voicesDirectory: URL {
        supportDirectory.appending(path: "voices", directoryHint: .isDirectory)
    }
    static var modelsDirectory: URL {
        supportDirectory.appending(path: "models", directoryHint: .isDirectory)
    }
    static var modelsHubDirectory: URL {
        modelsDirectory.appending(path: "hub", directoryHint: .isDirectory)
    }
    static var outputDirectory: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appending(path: "Desktop/MOSSlanding", directoryHint: .isDirectory)
    }
}

// MARK: - AppDelegate

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {

    private var statusItem: NSStatusItem?
    private var statusMenu: NSMenu?
    private var window: NSWindow?
    private var webView: WKWebView?
    private var scriptProxy: ScriptMessageProxy?
    private var serverTask: Task<Void, Never>?

    private let serverURL = URL(string: "http://127.0.0.1:8765")!

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        prepareAppDirectories()
        setupStatusItem()
        setupWindow()
        startSwiftServer()
        observeSleepWake()
    }

    func applicationWillTerminate(_ notification: Notification) {
        serverTask?.cancel()
    }

    private func prepareAppDirectories() {
        for dir in [
            AppPaths.supportDirectory,
            AppPaths.voicesDirectory,
            AppPaths.modelsDirectory,
            AppPaths.modelsHubDirectory,
            AppPaths.outputDirectory,
        ] {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
    }

    // MARK: Status bar

    private func setupStatusItem() {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem = item
        guard let button = item.button else { return }

        if let image = NSImage(systemSymbolName: "waveform", accessibilityDescription: "MOSSlanding") {
            image.isTemplate = true
            button.image = image
        } else {
            button.title = "ML"
        }

        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Show / Hide", action: #selector(toggleWindow), keyEquivalent: ""))
        menu.addItem(.separator())
        let loginItem = NSMenuItem(title: "Start at Login", action: #selector(toggleLoginItem), keyEquivalent: "")
        loginItem.state = isLoginItemEnabled() ? .on : .off
        menu.addItem(loginItem)
        menu.addItem(NSMenuItem(title: "Restart Server", action: #selector(restartServer), keyEquivalent: ""))
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "Quit MOSSlanding", action: #selector(quit), keyEquivalent: "q"))
        statusMenu = menu

        button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        button.action = #selector(handleStatusItemClick)
        button.target = self
    }

    @objc private func handleStatusItemClick() {
        guard let item = statusItem, let button = item.button else { return }
        let event = NSApp.currentEvent
        if event?.type == .rightMouseUp, let menu = statusMenu {
            item.menu = menu
            button.performClick(nil)
            item.menu = nil
        } else {
            toggleWindow()
        }
    }

    // MARK: Window

    private func setupWindow() {
        let config = WKWebViewConfiguration()
        let webV = WKWebView(frame: .zero, configuration: config)
        if #available(macOS 13.3, *) {
            webV.isInspectable = true
        } else {
            config.preferences.setValue(true, forKey: "developerExtrasEnabled")
        }
        webV.navigationDelegate = self
        webV.uiDelegate = self
        webV.allowsMagnification = false

        let proxy = ScriptMessageProxy(delegate: self)
        scriptProxy = proxy
        config.userContentController.add(proxy, name: "pickVoiceFile")
        self.webView = webV

        let win = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 680, height: 640),
            styleMask: [.titled, .closable, .resizable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        win.title = "MOSSlanding"
        win.contentView = webV
        win.minSize = NSSize(width: 480, height: 400)
        win.center()
        win.isReleasedWhenClosed = false

        webV.loadHTMLString(Self.loadingHTML, baseURL: nil)
        self.window = win
    }

    @objc func toggleWindow() {
        guard let win = window else { return }
        if win.isVisible && NSApp.isActive {
            win.orderOut(nil)
        } else {
            win.makeKeyAndOrderFront(nil)
            activateApp()
        }
    }

    private func activateApp() {
        if #available(macOS 14.0, *) {
            NSApp.activate()
        } else {
            NSApp.activate(ignoringOtherApps: true)
        }
    }

    // MARK: Server

    private func startSwiftServer() {
        guard let webuiDir = Bundle.main.url(forResource: "webui", withExtension: nil) else {
            logger.error("webui resource not found")
            return
        }

        serverTask = Task { [weak self] in
            let server = buildServer(webuiDir: webuiDir)
            await self?.loadUIWhenReady()
            do {
                try await server.run()
            } catch {
                logger.error("Swift server failed: \(error.localizedDescription, privacy: .public)")
            }
        }
        Task { await InferenceManager.shared.start() }
    }

    private func loadUIWhenReady() async {
        try? await Task.sleep(for: .milliseconds(150))
        guard let webV = webView else { return }
        webV.load(URLRequest(url: serverURL))
        window?.makeKeyAndOrderFront(nil)
        activateApp()
    }

    @objc private func restartServer() {
        Task {
            await InferenceManager.shared.terminate()
            await InferenceManager.shared.start()
        }
    }

    @objc private func quit() {
        Task {
            await InferenceManager.shared.terminate()
            NSApp.terminate(nil)
        }
    }

    // MARK: Login item (SMAppService, macOS 13+)

    private func isLoginItemEnabled() -> Bool {
        SMAppService.mainApp.status == .enabled
    }

    @objc private func toggleLoginItem() {
        let service = SMAppService.mainApp
        do {
            switch service.status {
            case .enabled:
                try service.unregister()
            case .notRegistered, .notFound:
                try service.register()
            case .requiresApproval:
                // User previously disabled in System Settings; open the panel
                // so they can re-enable.
                SMAppService.openSystemSettingsLoginItems()
            @unknown default:
                try service.register()
            }
        } catch {
            logger.error("Login item toggle failed: \(error.localizedDescription, privacy: .public)")
        }
        if let menu = statusMenu {
            for item in menu.items where item.title == "Start at Login" {
                item.state = isLoginItemEnabled() ? .on : .off
            }
        }
    }

    // MARK: Sleep / wake

    private func observeSleepWake() {
        let center = NSWorkspace.shared.notificationCenter
        center.addObserver(
            self,
            selector: #selector(handleWake),
            name: NSWorkspace.didWakeNotification,
            object: nil
        )
    }

    @objc private func handleWake() {
        Task { await InferenceManager.shared.restartIfNeeded() }
    }

    // MARK: Voice picker

    fileprivate func openVoiceFilePicker() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.message = "Choose a voice sample (WAV, MP3, M4A, FLAC)"
        panel.allowedContentTypes = [.audio]
        guard let win = window else { return }
        panel.beginSheetModal(for: win) { [weak self] response in
            guard response == .OK, let url = panel.url else { return }
            self?.copyVoiceFile(url)
        }
    }

    private func copyVoiceFile(_ url: URL) {
        let voicesDir = AppPaths.voicesDirectory
        try? FileManager.default.createDirectory(at: voicesDir, withIntermediateDirectories: true)
        let dest = voicesDir.appendingPathComponent(url.lastPathComponent)
        do {
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.copyItem(at: url, to: dest)
        } catch {
            logger.error("Voice copy failed: \(error.localizedDescription, privacy: .public)")
        }
    }

    private static let loadingHTML = """
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          display: flex; align-items: center; justify-content: center;
          height: 100vh; margin: 0;
          font-family: -apple-system, BlinkMacSystemFont, "SF Pro", sans-serif;
          background: #1e1e1e; color: #888; flex-direction: column; gap: 14px;
        }
        .spinner {
          width: 32px; height: 32px;
          border: 3px solid #333; border-top-color: #0a84ff;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        p { font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="spinner"></div>
      <p>Starting MOSSlanding……</p>
    </body>
    </html>
    """
}

// MARK: - WKNavigationDelegate / WKUIDelegate

extension AppDelegate: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: any Error) {
        logger.warning("WebView navigation failed: \(error.localizedDescription, privacy: .public)")
    }

    func webView(_ webView: WKWebView,
                 runOpenPanelWith parameters: WKOpenPanelParameters,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping ([URL]?) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = parameters.allowsMultipleSelection
        panel.allowedContentTypes = [.audio]
        if let win = webView.window {
            panel.beginSheetModal(for: win) { response in
                completionHandler(response == .OK ? panel.urls : nil)
            }
        } else {
            panel.begin { response in
                completionHandler(response == .OK ? panel.urls : nil)
            }
        }
    }
}

// MARK: - Script message proxy

private nonisolated final class ScriptMessageProxy: NSObject, WKScriptMessageHandler {
    weak var delegate: AppDelegate?

    init(delegate: AppDelegate) { self.delegate = delegate }

    func userContentController(_ controller: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.name == "pickVoiceFile" else { return }
        Task { @MainActor [weak delegate] in
            delegate?.openVoiceFilePicker()
        }
    }
}
